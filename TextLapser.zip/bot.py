import discord

intents = discord.Intents.default()
intents.message_content = True

client = discord.Client(intents=intents)

@client.event
async def on_ready():
    print(f'We have logged in as {client.user}')
    await client.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="messages burning"))

@client.event
async def on_message(message):
    if message.author == client.user:
        return

    if "http" and "gif" and "tenor" not in message.content:
        if 'gif' not in message.channel.name:
            return
        await message.channel.send("Only GIF's are allowed", delete_after=5)

    if "gif" and "http" and "tenor" not in message.content:
        if 'gif' not in message.channel.name:
            return
        await message.delete()

client.run('MTAxNTU0NzAzODgwNjU4MTI3MA.GaVu-7.yk20zWDIBp835XTuXHw2r1lG-Jl6MhZcL-V9lo')
